package com.harindra.tvlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class HomeOverrideAccessibilityService : AccessibilityService() {

    private var lastLaunchMs = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString()?.lowercase() ?: return
        if (pkg == packageName.lowercase()) return

        // Detect HikeenLauncher or any factory TV Home Launcher coming to foreground
        val isStockHome = pkg.contains("hikeen") ||
            pkg == "com.google.android.tvlauncher" ||
            pkg == "com.google.android.apps.tv.launcherx" ||
            pkg == "com.mitv.tvhome" ||
            pkg == "com.tcl.cyberui" ||
            pkg == "com.sony.dtv.homelauncher" ||
            pkg == "com.hisense.tv.launcher" ||
            pkg.endsWith(".tvlauncher") ||
            pkg.endsWith(".launcher")

        if (!isStockHome) return

        val now = System.currentTimeMillis()
        if (now - lastLaunchMs < 350L) return
        lastLaunchMs = now

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        }
        try {
            startActivity(intent)
        } catch (_: Throwable) { }
    }

    override fun onInterrupt() { }
}
