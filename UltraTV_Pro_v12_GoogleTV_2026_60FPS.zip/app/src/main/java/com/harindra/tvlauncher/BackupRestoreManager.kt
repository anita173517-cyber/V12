package com.harindra.tvlauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupRestoreManager {

    private const val BACKUP_FILENAME = "UltraTV_Pro_Backup.json"

    fun getBackupFile(context: Context): File {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        return File(dir, BACKUP_FILENAME)
    }

    fun exportToJson(prefs: PrefsManager): String {
        val root = JSONObject().apply {
            put("schemaVersion", 11)
            put("themeIndex", prefs.themeIndex)
            put("performanceTier", prefs.performanceTier)
            put("showHeroBanner", prefs.showHeroBanner)
            put("showLeftSidebar", prefs.showLeftSidebar)
            put("showMovieBoxRow", prefs.showMovieBoxRow)
            put("enable4dAnimations", prefs.enable4dAnimations)
            put("is24HourClock", prefs.is24HourClock)
            put("gridColumns", prefs.gridColumns)
            put("bootMode", prefs.bootMode)
            put("autoLaunchPackage", prefs.autoLaunchPackage)
            put("m3uUrl", prefs.m3uUrl)
            put("preferredIptvPlayer", prefs.preferredIptvPlayer)
            put("pinnedApps", JSONArray(prefs.getPinnedPackages()))
            put("hiddenApps", JSONArray(prefs.getHiddenPackages().toList()))
            put("lockedApps", JSONArray(prefs.getLockedPackages().toList()))
            put("favChannels", JSONArray(prefs.getFavoriteChannelIds().toList()))
            put("favMovies", JSONArray(prefs.getFavoriteMovieTitles().toList()))
            val dials = JSONObject()
            for (d in 1..9) {
                val t = prefs.getSpeedDial(d)
                if (t.isNotBlank()) dials.put(d.toString(), t)
            }
            put("speedDials", dials)
        }
        return root.toString(2)
    }

    fun saveBackupFile(context: Context, prefs: PrefsManager): Result<File> {
        return try {
            val file = getBackupFile(context)
            file.writeText(exportToJson(prefs), Charsets.UTF_8)
            Result.success(file)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    fun restoreFromFile(context: Context, prefs: PrefsManager): Result<String> {
        return try {
            val file = getBackupFile(context)
            if (!file.exists()) return Result.failure(Exception("No backup file found at ${file.name}"))
            importFromJson(prefs, file.readText(Charsets.UTF_8))
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    fun importFromJson(prefs: PrefsManager, jsonText: String): Result<String> {
        return try {
            val root = JSONObject(jsonText)
            if (root.has("themeIndex")) prefs.themeIndex = root.optInt("themeIndex", 0)
            if (root.has("performanceTier")) prefs.performanceTier = root.optInt("performanceTier", -1)
            if (root.has("showHeroBanner")) prefs.showHeroBanner = root.optBoolean("showHeroBanner", true)
            if (root.has("showLeftSidebar")) prefs.showLeftSidebar = root.optBoolean("showLeftSidebar", true)
            if (root.has("showMovieBoxRow")) prefs.showMovieBoxRow = root.optBoolean("showMovieBoxRow", true)
            if (root.has("enable4dAnimations")) prefs.enable4dAnimations = root.optBoolean("enable4dAnimations", true)
            if (root.has("is24HourClock")) prefs.is24HourClock = root.optBoolean("is24HourClock", false)
            if (root.has("gridColumns")) prefs.gridColumns = root.optInt("gridColumns", 5)
            if (root.has("bootMode")) prefs.bootMode = root.optInt("bootMode", 0)
            if (root.has("autoLaunchPackage")) prefs.autoLaunchPackage = root.optString("autoLaunchPackage", "")
            if (root.has("m3uUrl")) prefs.m3uUrl = root.optString("m3uUrl", "")
            if (root.has("preferredIptvPlayer")) prefs.preferredIptvPlayer = root.optString("preferredIptvPlayer", "")

            root.optJSONArray("pinnedApps")?.let { arr ->
                prefs.savePinnedPackages((0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } })
            }
            root.optJSONArray("hiddenApps")?.let { arr ->
                prefs.saveHiddenPackages((0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet())
            }
            root.optJSONArray("lockedApps")?.let { arr ->
                prefs.saveLockedPackages((0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet())
            }
            root.optJSONArray("favChannels")?.let { arr ->
                prefs.saveFavoriteChannelIds((0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet())
            }
            root.optJSONArray("favMovies")?.let { arr ->
                prefs.saveFavoriteMovieTitles((0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet())
            }
            root.optJSONObject("speedDials")?.let { dials ->
                for (d in 1..9) {
                    val v = dials.optString(d.toString(), "")
                    if (v.isNotBlank()) prefs.setSpeedDial(d, v)
                }
            }
            Result.success("Backup restored successfully!")
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }
}
